package hiberPractise_3;
import javax.persistence.*;    

@Entity  
@Table(name="contractemployee")  
@PrimaryKeyJoinColumn(name="ID")  
public class ContractEmployee extends Employee{  
      
    @Column(name="wage")  
    private float wage;  
      
    @Column(name="duration")  
    private String duration;

	public float getWage() {
		return wage;
	}

	public void setWage(float wage) {
		this.wage = wage;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	
}  