package hiberPractise;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class TestClass
{
	public static void main(String args[])
	{
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		
		//Inserting into the database.
		Student stud1 = new Student(14, "Bale", "London", 80);
		session.save(stud1);
		Student stud2 = new Student(25, "Razak", "Lahore", 50);
		session.save(stud2);
		Student stud3 = new Student(37, "Ollie", "Auckland", 60);
		session.save(stud3);
		Student stud4 = new Student(24, "Josh", "New South Wales", 55);
		session.save(stud4);
		Student stud5 = new Student(95, "Ramirez", "Madrid", 40);
		session.save(stud5);
		Student stud6 = new Student(78, "Kroos", "Munich", 46);
		session.save(stud6);
		
		
		/*
		//Updating student details.
		Query q1 = session.createQuery("update Student set name=:n,city=:c,marks=:m where id=:i");
		q1.setParameter("n","Stuart");
		q1.setParameter("c", "Liverpool");
		q1.setParameter("m", 99);
		q1.setParameter("i", 2);
		int status = q1.executeUpdate();
		System.out.println(status+"\n Successfully updated.");
		*/
		
		
		/*
		//Deleting a record
		Query del = session.createQuery("delete from Student where city=:c");
		del.setParameter("c", "Liverpool");
		del.executeUpdate();
		System.out.println("Update successful");
		*/
		System.out.println();
		//printing student details those who have marks greater than 50.
		System.out.println("Students having marks more than 50");
		Query find = session.createQuery("from Student where marks>50");
		List<Student> marksGtFifty=find.getResultList();
		for (Student stud : marksGtFifty)
		{
			System.out.println(stud);
		}
		System.out.println();
		//printing the student details.
		System.out.println("All student details");
		Query q = session.createQuery("from Student");
		List<Student> studentList = q.getResultList();
		for (Student stud : studentList)
		{
			System.out.println(stud);
		}
		
		t.commit();
		factory.close();
		session.close();
	}
}