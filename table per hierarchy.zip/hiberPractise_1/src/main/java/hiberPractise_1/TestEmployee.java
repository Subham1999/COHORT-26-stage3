package hiberPractise_1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;


public class TestEmployee {

	public static void main(String[] args) 
	{
		StandardServiceRegistry srr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata meta = new MetadataSources(srr).getMetadataBuilder().build();
		
		SessionFactory factory = meta.getSessionFactoryBuilder().build();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		
		Employee emp = new Employee();
		emp.setName("Kulkarni");
		
		Regular_Employee rEmp = new Regular_Employee();
		rEmp.setName("Ramesh");
		
		rEmp.setSalary(355500.25);
		rEmp.setIncrement(100500.25);
		
		Contract_Employee cEmp = new Contract_Employee();
		cEmp.setName("Fredrick");
		cEmp.setWagePerHour(159870);
		cEmp.setTenure(20);

		session.persist(emp);
		session.persist(rEmp);
		session.persist(cEmp);
		
		t.commit();
		session.close();
		System.out.println("Success");
	}

}
