package hiberPractise_1;

import javax.persistence.*;

@Entity
@DiscriminatorValue("contract employee")
public class Contract_Employee extends Employee
{
	@Column(name="wage")
	private double wagePerHour;
	private int tenure;
	
	
	public double getWagePerHour() {
		return wagePerHour;
	}
	public void setWagePerHour(double wagePerHour) {
		this.wagePerHour = wagePerHour;
	}
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	
	
}
