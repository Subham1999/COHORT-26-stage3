package hiberPractise_1;

import javax.persistence.*;

@Entity
@DiscriminatorValue("regular employee")
public class Regular_Employee extends Employee
{
	private double salary;
	private double increment;
	
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public double getIncrement() {
		return increment;
	}
	public void setIncrement(double increment) {
		this.increment = increment;
	}
	
	
	
}
