package hiberPractise_1;

import javax.persistence.*;

@Entity
@Table(name="empTabl_1")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="type", discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue(value = "employee")
public class Employee 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)//auto generation.
	private int empId;
	
	@Column(name = "empName")
	private String name;
	
	
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	

}
