package hiberPractise_2;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class StoreData {

	public static void main(String[] args) 
	{
		StandardServiceRegistry srr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata meta = new MetadataSources(srr).getMetadataBuilder().build();
		
		SessionFactory factory = meta.getSessionFactoryBuilder().build();
		Session session = factory.openSession();
		
		Transaction t = session.beginTransaction();
		
		Employee e1 = new Employee();
		//e1.setId(101);

		e1.setName("Ayush Patel");
		
		
		RegularEmployee re = new RegularEmployee();
		//re.setId(102);
		re.setName("Ajay Kumar");
		re.setSalary(98000);
		re.setBonus(12000);
		
		ContractEmployee ce = new ContractEmployee();
		ce.setName("Suresh Yadav");
		//ce.setId(103);
		ce.setWage(15000);
		ce.setDuration("15 hours");
		
		session.persist(e1);
		session.persist(re);
		session.persist(ce);
		
		t.commit();
		session.close();
		System.out.println("success");
	}

}
