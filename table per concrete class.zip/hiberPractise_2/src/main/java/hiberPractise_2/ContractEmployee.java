package hiberPractise_2;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@AttributeOverrides({
	 @AttributeOverride(name="id", column=@Column(name="id")),
	 @AttributeOverride(name="name",column=@Column(name="name"))
})
public class ContractEmployee extends Employee 
{
	@Column(name="wage")
	private float wage;
	
	@Column(name="duration")
	private String duration;

	
	public float getWage() {
		return wage;
	}

	public void setWage(float wage) {
		this.wage = wage;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}
	
}
